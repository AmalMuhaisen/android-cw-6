public class Movie {

    public class movie{
        String title;
        String mainActor;
        Double movieRate;
        int pdRate;
        String genre;

        public movie(String title, String mainActor, Double movieRate, int pdRate, String genre) {
            this.title = title;
            this.mainActor = mainActor;
            this.movieRate = movieRate;
            this.pdRate = pdRate;
            this.genre = genre;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getMainActor() {
            return mainActor;
        }

        public void setMainActor(String mainActor) {
            this.mainActor = mainActor;
        }

        public Double getMovieRate() {
            return movieRate;
        }

        public void setMovieRate(Double movieRate) {
            this.movieRate = movieRate;
        }

        public int getPdRate() {
            return pdRate;
        }

        public void setPdRate(int pdRate) {
            this.pdRate = pdRate;
        }

        public String getGenre() {
            return genre;
        }

        public void setGenre(String genre) {
            this.genre = genre;
        }
    }
}
